
<!--footer-->
<footer class="fixed-bottom w-100 container-fluid  py-1" style="background-color:   background-color: #7f5a83;
    background-image: linear-gradient(315deg, #7f5a83 0%, #0d324d 74%);">
    <div class="container">
        <div class="row text-center">
            <div class="col-md-3 mb-1">
            </div>
            <div class="col-md-6 mb-1">
                <h5 style="color:white;">© NOYON & TARIT, 2022 </h5>
                <span style="color: white">Developed by:</span>
                <a href="https://bhyeanhasan.github.io/">Md. Babul Hasan (NoYoN) & Shahriar Tarit</a>
            </div>

            <div class="col-md-3">

            </div>
        </div>
    </div>
</footer>